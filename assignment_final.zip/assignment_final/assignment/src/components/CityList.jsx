

import React, { useEffect, useState } from "react";


const cityData = [

  { name: "Chennai" },
  { name: "Bangalore" },
  { name: "Mumbai" }
];

function CityList() {
  const [city, setCity] = useState([]);

  useEffect(() => {
    setCity(cityData);
  }, []);

  const handleChange = (e) => {
    const { name, checked } = e.target;
    if (name === "allSelect") {
      let tempCity = city.map((city) => {
        return { ...city, isChecked: checked };
      });
      setCity(tempCity);
    } else {
      let tempCity = city.map((city) =>
        city.name === name ? { ...city, isChecked: checked } : city
      );
      setCity(tempCity);
    }
  };

  return (
    <div >
      <form >
        <h1>City Selections</h1>
        <div >
          <input
            type="checkbox"
         
            name="allSelect"
          
            checked={!city.some((city) => city?.isChecked !== true)}
            onChange={handleChange}
          />
          <label >All Select</label>
        </div>
        {city.map((city, index) => (
          <div  key={index}>
            <input
              type="checkbox"
            
              name={city.name}
              checked={city?.isChecked || false}
              onChange={handleChange}
            />
            <label >{city.name}</label>
          </div>
        ))}
      </form>
     
    </div>
  );
}

export  {CityList};